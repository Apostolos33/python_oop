from project.task import Task


class Section:
    def __init__(self, name: str):
        self.name = name
        self.tasks = []

    def add_task(self, new_task: Task):
        if new_task in self.tasks:
            return f"Task is already in the section {self.name}"
        self.tasks.append(new_task)
        return f"Task {new_task.details()} is added to the section"

    def complete_task(self, task_name: str):
        t_name = next((n for n in self.tasks if task_name == n.name), None)
        if t_name:
            t_name.completed = True
            return f"Completed task {task_name}"
        return f"Could not find task with the name {task_name}"

    def clean_section(self):
        tasks_removed = 0
        for task in self.tasks:
            if task.completed:
                self.tasks.remove(task)
                tasks_removed += 1
        return f"Cleared {tasks_removed} tasks."

    def view_section(self):
        result = ""
        result += f"Section {self.name}:\n"
        for task in self.tasks:
            result += f"{task.details()}\n"
        return result
